import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup} from '@angular/forms';
import { FileSelectDirective, FileUploader} from 'ng2-file-upload';

const uri = "http://localhost:4500/uploads";

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {

  profileForm: FormGroup;
  error: string;


  
  uploader: FileUploader = new FileUploader({url:uri});
  attachmentList:any = [];
  fileUpload = {status: '', message: '', filePath: ''};

  constructor( private fb: FormBuilder) { 

    this.uploader.onBeforeUploadItem = (item) => {
      item.withCredentials = false;
    }
    this.uploader.onCompleteItem = (item:any, response:any, status:any,header:any) => {
      /* this.attachmentList.push(JSON.parse(response)); */
    }
  }

  ngOnInit() {
    this.profileForm = this.fb.group({
      name: [''],
      profile: ['']
    });
  }

  onSelectedFile(event) {
    if (event.target.files.length != 0) {
      const file = event.target.files[0];
      console.log(event.target.files[0]['name']);
      this.profileForm.get('profile').setValue(file);
    }
  }

}
