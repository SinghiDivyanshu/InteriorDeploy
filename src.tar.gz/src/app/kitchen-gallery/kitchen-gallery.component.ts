import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kitchen-gallery',
  templateUrl: './kitchen-gallery.component.html',
  styleUrls: ['./kitchen-gallery.component.css']
})
export class KitchenGalleryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
