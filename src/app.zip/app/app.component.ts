import { Component } from '@angular/core';
import { trigger, animate, transition, state, style,keyframes, group} from '@angular/animations';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Interior';
}
